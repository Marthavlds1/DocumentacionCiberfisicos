# 🔴 LED Controller — Flask API + Front separado + ESP32 Física

## Arquitectura

```
[Navegador]           [Servidor front]          [Flask API]          [ESP32 física]
  index.html   ←──   python -m http.server   →  POST /api/state  →   NeoPixel WS2812B
  app.js                                         GET  /api/state  ←   polling 500ms
```

Dos servidores completamente independientes:

| Servidor     | Qué hace                              | Puerto |
|--------------|---------------------------------------|--------|
| **Flask**    | Solo API (GET/POST `/api/state`)       | 5000   |
| **Front**    | Sirve HTML/JS/CSS estáticos           | 5500   |

---

## Estructura del proyecto

```
led-esp32-split/
├── backend/
│   ├── app.py              ← Servidor Flask (solo API)
│   ├── requirements.txt
│   ├── Procfile            ← Para Render/Railway
│   └── data/
│       └── state.json
├── frontend/
│   ├── index.html
│   ├── app.js              ← Línea DEFAULT_API: pon la IP de tu PC
│   └── styles.css
└── esp32-led-fisico.ino    ← Código Arduino
```

---

## Paso 1 — Arrancar el backend Flask

```bash
cd backend
pip install flask flask-cors
python app.py
```

Deberías ver:
```
🟢  API corriendo en      http://0.0.0.0:5000
📡  ESP32 apunta a        http://<TU_IP>:5000/api/state
🌐  Front llama a         http://<TU_IP>:5000/api/state
```

> Para saber tu IP local: `ipconfig` (Windows) · `hostname -I` (Linux/Mac)

---

## Paso 2 — Arrancar el servidor del front

```bash
cd frontend
python -m http.server 5500
```

Abre **http://localhost:5500** en el navegador.

O usa **VS Code Live Server** (clic derecho → "Open with Live Server").

---

## Paso 3 — Configurar la URL del backend en el front

Dos opciones:

**A) Editar `frontend/app.js`** (línea 8):
```js
const DEFAULT_API = "http://192.168.X.X:5000";
```

**B) Cambiarlo desde la UI** — en el campo "URL API" del panel derecho,
escribe la IP de tu PC y presiona **Aplicar**. Se guarda en `localStorage`.

---

## Paso 4 — Flashear la ESP32

En `esp32-led-fisico.ino`, cambia las 3 líneas:

```cpp
const char* WIFI_SSID = "TuRedWiFi";
const char* WIFI_PASS = "TuContraseña";
const char* STATE_URL = "http://192.168.X.X:5000/api/state";
```

Sube con Arduino IDE. Abre Monitor Serial a **115200 baud**.

Al conectar verás un **flash verde** en los LEDs. Si falla → **flash rojo**.

---

## Wiring

```
ESP32  GPIO 5  ──►  DIN  de la tira WS2812B
ESP32  GND     ──►  GND  de la tira
Fuente 5 V     ──►  VCC  de la tira
```

---

## API endpoints

| Método | Ruta            | Descripción                                    |
|--------|-----------------|------------------------------------------------|
| GET    | `/api/state`    | Lee el estado actual (ESP32 y front lo usan)   |
| POST   | `/api/state`    | `{ "color": "#RRGGBB", "count": 0-8 }`         |
| GET    | `/api/health`   | `{ "status": "ok" }`                           |
