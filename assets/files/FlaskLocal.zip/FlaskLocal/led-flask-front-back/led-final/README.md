# 💡 Control de Tira LED — Flask + ESP32

## Estructura
```
led-flask-front-back/
├── app.py               ← Servidor Flask (backend)
├── requirements.txt     ← Dependencias Python
├── Procfile             ← Para deploy en Render (nube)
├── data/
│   └── state.json       ← Estado guardado de la tira
├── static/
│   ├── index.html       ← Interfaz web
│   ├── app.js           ← Lógica del frontend
│   └── styles.css       ← Estilos
└── esp32-led.ino        ← Código Arduino para el ESP32
```

---

## 🖥️ OPCIÓN A — Correr en local (tu PC)

### 1. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 2. Correr el servidor
```bash
python app.py
```
Abre el navegador en: **http://localhost:5000**

### 3. Encontrar tu IP local (para el ESP32)
En Windows, abre CMD y escribe:
```
ipconfig
```
Busca **"Dirección IPv4"** → algo como `192.168.1.105`

### 4. Configurar el ESP32
En `esp32-led.ino` cambia estas líneas:
```cpp
const char* WIFI_SSID = "NombreDeTuWiFi";
const char* WIFI_PASS = "PasswordWiFi";
const char* STATE_URL = "http://192.168.1.105:5000/api/state"; // ← tu IP
```

---

## ☁️ OPCIÓN B — Deploy en Render (gratis, 24/7)

### 1. Sube el proyecto a GitHub
- Crea un repo nuevo en github.com
- Sube todos los archivos

### 2. Crea una cuenta en render.com

### 3. Nuevo servicio
- New → Web Service → conecta tu repo de GitHub
- **Build command:** `pip install -r requirements.txt`
- **Start command:** `gunicorn app:app`
- Plan: **Free**

### 4. Render te da una URL pública
Algo como: `https://led-control-xxxx.onrender.com`

### 5. Configura el ESP32 con la URL de la nube
```cpp
const char* STATE_URL = "http://led-control-xxxx.onrender.com/api/state";
```
> ⚠️ El plan gratuito de Render "duerme" tras 15 min sin tráfico.
> Para proyectos serios usa el plan $7/mes o corre en local.

---

## 📡 API

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/` | Interfaz web |
| GET | `/api/state` | Leer estado actual |
| POST | `/api/state` | Guardar estado `{ color, count }` |

---

## 🔧 Librerías Arduino necesarias
Instala desde **Herramientas → Administrar librerías**:
- **Adafruit NeoPixel** (by Adafruit)
- **ArduinoJson** (by Benoit Blanchon)
